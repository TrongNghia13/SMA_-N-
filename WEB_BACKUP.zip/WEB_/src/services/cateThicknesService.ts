
import { AxiosRequestConfig } from 'axios';
import AxiosCommon from '../commons/axiosCommon';
import APIURL from '../configs/APIConfig';
import CATE_THICKNESS from '../models/cateThickness';

class CateThicknesService {
    private aAxiosCommon: AxiosCommon;
    constructor() {
        this.aAxiosCommon = new AxiosCommon();
    }
    
    public GetList = async () => {
        var optionRequest: AxiosRequestConfig = {};
        optionRequest.method = 'POST';
        optionRequest.url = APIURL.CHIEUDAY_LIST;
        optionRequest.data = { };
        var data = await this.aAxiosCommon.request<CATE_THICKNESS>(optionRequest);
        return data;
    }
    
    public GetByMa = async (ma: string) => {
        var optionRequest: AxiosRequestConfig = {};
        optionRequest.method = 'POST';
        optionRequest.url = APIURL.CHIEUDAY_GETBYMA;
        optionRequest.data = { ma };
        var data = await this.aAxiosCommon.requestSingle<CATE_THICKNESS>(optionRequest);
        return data;
    }

    public Manager = async (req: CATE_THICKNESS) => {
        var optionRequest: AxiosRequestConfig = {};
        optionRequest.method = 'POST';
        optionRequest.url = APIURL.CHIEUDAY_MANAGER;
        optionRequest.data = req;
        var data = await this.aAxiosCommon.request<any>(optionRequest);
        return data;
    }

    public Delete = async (ma: string) => {
        var optionRequest: AxiosRequestConfig = {};
        optionRequest.method = 'POST';
        optionRequest.url = APIURL.CHIEUDAY_DELETE;
        optionRequest.data = { ma} ;
        var data = await this.aAxiosCommon.requestSingle<any>(optionRequest);
        return data;
    }

}
export default CateThicknesService;
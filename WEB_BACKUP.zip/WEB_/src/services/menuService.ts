
import { AxiosRequestConfig } from 'axios';
import AxiosCommon from '../commons/axiosCommon';
import APIURL from '../configs/APIConfig';
import mainMenu from '../models/mainMenu';
import menus, { menusVm } from '../models/menus';
import { MenuPage } from '../models/ui/treeMenu';

class MenuService {
    private aAxiosCommon: AxiosCommon;
    constructor() {
        this.aAxiosCommon = new AxiosCommon();
    }

    public GetMainMenuList = async () => {
        var optionRequest: AxiosRequestConfig = {};
        optionRequest.method = 'POST';
        optionRequest.url = APIURL.MAIN_MENU_LIST;
        optionRequest.data = {};
        var data = await this.aAxiosCommon.requestListObject<mainMenu>(optionRequest);
        return data;
    }

    public GetMainMenuById = async (id: number) => {
        var optionRequest: AxiosRequestConfig = {};
        optionRequest.method = 'POST';
        optionRequest.url = APIURL.MAIN_MENU_GETBYID;
        optionRequest.data = { Id: id };
        var data = await this.aAxiosCommon.requestSingle<mainMenu>(optionRequest);
        return data;
    }

    public MainMenuManager = async (req: mainMenu) => {
        var optionRequest: AxiosRequestConfig = {};
        optionRequest.method = 'POST';
        optionRequest.url = APIURL.MAIN_MENU_MANAGER;
        optionRequest.data = req;
        var data = await this.aAxiosCommon.request<any>(optionRequest);
        return data;
    }

    public MainMenuDelete = async (id: number) => {
        var optionRequest: AxiosRequestConfig = {};
        optionRequest.method = 'POST';
        optionRequest.url = APIURL.MAIN_MENU_DELETE;
        optionRequest.data = { id: id};
        var data = await this.aAxiosCommon.requestSingle<any>(optionRequest);
        return data;
    }

    public GetMenuList = async (mainMenuID: number ) => {
        var optionRequest: AxiosRequestConfig = {};
        optionRequest.method = 'POST';
        optionRequest.url = APIURL.MENU_LIST;
        optionRequest.data = { mainMenuID: mainMenuID };
        var data = await this.aAxiosCommon.request<menusVm>(optionRequest);
        return data;
    }

    public GetMenuById = async (id: number) => {
        var optionRequest: AxiosRequestConfig = {};
        optionRequest.method = 'POST';
        optionRequest.url = APIURL.MENU_GETBYID;
        optionRequest.data = { Id: id };
        var data = await this.aAxiosCommon.requestSingle<menus>(optionRequest);
        return data;
    }

    public MenuManager = async (req: menus) => {
        var optionRequest: AxiosRequestConfig = {};
        optionRequest.method = 'POST';
        optionRequest.url = APIURL.MENU_MANAGER;
        optionRequest.data = req;
        var data = await this.aAxiosCommon.request<any>(optionRequest);
        return data;
    }

    public MenuDelete = async (id: number) => {
        var optionRequest: AxiosRequestConfig = {};
        optionRequest.method = 'POST';
        optionRequest.url = APIURL.MENU_DELETE;
        optionRequest.data = { id: id};
        var data = await this.aAxiosCommon.requestSingle<any>(optionRequest);
        return data;
    }

    public GetMenuByUserLogin = async (id: number) => {
        var optionRequest: AxiosRequestConfig = {};
        optionRequest.method = 'GET';
        optionRequest.url = APIURL.MENU_BY_USER_LOGIN+id;
        optionRequest.data = {id : id};
        var data = await this.aAxiosCommon.requestSingle<MenuPage>(optionRequest);
        return data;
    }

}
export default MenuService;
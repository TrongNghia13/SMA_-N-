const AppConfig = {
    USER_LOGIN_TOKEN_KEY: 'SMA_LOGIN_TOKEN_KEY',
}
export default AppConfig;
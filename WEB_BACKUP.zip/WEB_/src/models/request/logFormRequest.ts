interface logFormRequest {
    loginid: number,
    userid: number,
    username: string,
    menukey: string
}
export default logFormRequest;
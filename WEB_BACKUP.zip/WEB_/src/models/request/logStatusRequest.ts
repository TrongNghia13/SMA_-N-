interface logStatusRequest {    
    frdate: Date,
    todate: Date
}
export default logStatusRequest;
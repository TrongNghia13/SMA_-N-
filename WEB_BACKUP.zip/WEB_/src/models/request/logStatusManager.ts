interface logStatusManager {    
    loginid: number,
    userid: number,
    username: string,
    iplogin: string,
    erpid: number,
    donviud: string    
}
export default logStatusManager;
interface cateStandard {
    standardID: string;
    standardName: string;
    // managetype: number

}
export default cateStandard;
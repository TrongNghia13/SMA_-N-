interface cateThickness {
    thicknessID: string;
    thicknessName: string;    
   
}
export default cateThickness;
interface mainMenu {
    mainMenuID: number;
    mainMenuName: string;
    sortOrder: number;
    icon: string;
}
export default mainMenu;
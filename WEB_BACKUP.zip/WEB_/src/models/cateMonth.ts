interface cateMonth {
    monthID: string,
    explainDetail: string,
    isLock: number
}
export default cateMonth;
import logo from './logo.svg';
import './app.scss';
import React, { Suspense, Fragment } from 'react';
// import { Route, Switch } from 'react-router';
import { Spin } from 'antd';
import { Helmet } from "react-helmet";
import { Form } from "antd";
import { Route, Routes,BrowserRouter } from "react-router-dom";
import PrivateRoute from "../../routes/privateRoute"
//import Login from "../pages/login/Login";
 const Login = React.lazy(() => import('../../pages/login'));
 const CateMonth = React.lazy(() => import('../../pages/cateMonthPage'));

const Homepage = React.lazy(() => import('../shared/layout/index'));

const loading = () => <div className="spin-loading"><Spin tip="Loading ..." /></div>;
//const WrappedLogin = Form.create<FieldType>({ name: "login" })(Login);
const App: React.FC = () => {
  return (
    <Fragment>
      <Helmet>
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0" />
        <meta charSet="utf-8" />
        <title>SMA Application</title>
      </Helmet>
      <BrowserRouter>
        <Suspense fallback={loading()}>
          <Routes>
            {/* <Route path="/homepage" element={<Homepage />} /> */}
            <Route path="/" element={<PrivateRoute><Homepage /></PrivateRoute>} />
            <Route path="/Login" element={<Login />} />
            <Route path="/CateMonth" element={<CateMonth />} />

          </Routes>
        </Suspense>
      </BrowserRouter>
    </Fragment>
  );
}

export default App;

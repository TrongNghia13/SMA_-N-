import React, { Fragment, useState, useEffect } from 'react';
import { GridColumn, DataGrid } from 'rc-easyui';
import { Button, message, Modal, Input } from 'antd';
import CateThicknesCotroller from '../../services/cateThicknesService';
import cateThickness from '../../models/cateThickness';
import { APIStatus } from '../../configs/APIConfig';

const cateThicknesCotroller = new CateThicknesCotroller();

const { confirm } = Modal;
const ChieuDay: React.FC = () => {        
    const [model, setModel] = useState({ lst: Array<cateThickness>(), loading: true });
    const datamodelthicknessIDInit = {
        thicknessID: '',        
        thicknessName: '',
       
    };
    const [modelthicknessID, setmodelthicknessID] = useState((() => {
        let dataInit: cateThickness = datamodelthicknessIDInit
        return dataInit;
    }));
    const [dataSelectChieuDay, setDataSelectChieuDay] = useState((() => {
        let dataInit = { model: datamodelthicknessIDInit, thicknessID: '' }
        return dataInit;
    }));
    const [optionChieuDay, setOptionChieuDay] = useState((() => {
        let dataInit = { thicknessID: '', thicknessName: '', isEditing: false, isSubmit: false };
        return dataInit;
    }));
    const [selectChieuDay, setSelectChieuDay] = useState((() => {
        let dataInit: cateThickness = {} as any;
        return dataInit;
    })); 

    useEffect(() => {
        LoadDMChieuDay();
    }, []);

    const LoadDMChieuDay = async (callback?: any) => {
        var dataDMChieuDay = await cateThicknesCotroller.GetList();
        setModel({
            ...model,
            lst: dataDMChieuDay.data,
            loading: false
        });
        setTimeout(() => {
            if (callback) callback(dataDMChieuDay.data);
        }, 300);
    }    
    
    const onSelectChieuDay = (selection: cateThickness, dataInit?: Array<cateThickness>) => {
        if (optionChieuDay.isEditing && (dataInit == null || dataInit === undefined)) {
            setDataSelectChieuDay({ ...dataSelectChieuDay, model: datamodelthicknessIDInit, thicknessID: '' });            
        }
        else {            
            var chieudayItem: cateThickness = datamodelthicknessIDInit;
            if (dataInit) {
                chieudayItem = dataInit.find((element) => {
                    return element.thicknessID === selection.thicknessID;
                }) || datamodelthicknessIDInit;
            }
            else {
                chieudayItem = model.lst.find((element) => {
                    return element.thicknessID === selection.thicknessID;
                }) || datamodelthicknessIDInit;
            }
           
            setmodelthicknessID(chieudayItem);
            setDataSelectChieuDay({ ...dataSelectChieuDay, model: chieudayItem });

            setOptionChieuDay(prevState => ({
                ...prevState,
                thicknessID: chieudayItem.thicknessID,
                thicknessName: chieudayItem.thicknessName,
                isEditing: false,
                isSubmit: false,
            }));            
        }
    }

    const handleChangeInput = (e: React.FormEvent<HTMLInputElement>) => {
        e.preventDefault();
        let { type, name, value } = e.currentTarget;
        setmodelthicknessID({ ...modelthicknessID, [name]: (type === 'number' ? parseFloat(value) : value) });
    }

    const AddChieuDay = (e: any) => {
        setOptionChieuDay(prevState => ({
            ...prevState,
            isEditing: true
        }));
        setDataSelectChieuDay({ ...dataSelectChieuDay, model: datamodelthicknessIDInit, thicknessID: '' });
        setmodelthicknessID(datamodelthicknessIDInit);
    }

    const EditChieuDay = (e: any) => {
        if (optionChieuDay.thicknessID = '') {
            message.error('Vui lòng chọn thông tin để sửa');
            return false;
        }
        setOptionChieuDay(prevState => ({ ...prevState, isEditing: true }));
    }

    const DeleteChieuDay = (e: any) => {       
        if (optionChieuDay.thicknessID === '') {            
            message.error('Vui lòng chọn thông tin để xóa');
            return false;
        }
        confirm({            
            title: 'Xác nhận',
            content: 'Bạn có chắc muốn xóa danh mục: ' + optionChieuDay.thicknessName + '?',
            onOk() {
                OnDeletedChieuDay(e);
            },
            onCancel() { },
        });
    }

    const OnDeletedChieuDay = async (e: any) => {
        var reDelete = await cateThicknesCotroller.Delete(optionChieuDay.thicknessID);;
        if (reDelete.status === APIStatus.ERROR) {
            message.error(reDelete.message);
        }
        else {                        
            await LoadDMChieuDay();
            await CancelChieuDay(e);
        }
    }

    const SaveChieuDay = async (e: any) => {
        e.preventDefault();
        if (modelthicknessID.thicknessID === '') {
            message.error('Vui lòng nhập mã chiều dầy');
            return false;
        } 
        if (modelthicknessID.thicknessName === '') {
            message.error('Vui lòng nhập tên chiều dầy');
            return false;
        } 
        setOptionChieuDay({ ...optionChieuDay, isSubmit: true });
        var data = await cateThicknesCotroller.Manager(modelthicknessID);
        const thicknessIDChieuday = modelthicknessID.thicknessID;
        if (data.status === APIStatus.ERROR) {
            message.error(data.message);
            setOptionChieuDay({ ...optionChieuDay, isSubmit: false });
        }
        else {
            //  message.success((modelthicknessID.thicknessIDnagetype === 1 ? "Thêm":"Cập nhật")+" thành công"); 
            CancelChieuDay(e);
            await LoadDMChieuDay(function (datas: Array<cateThickness>) {
                var chieudayItem = datas.find((element) => {
                    return element.thicknessID === thicknessIDChieuday;
                });
                if (chieudayItem) {
                    onSelectChieuDay(chieudayItem, datas);                    
                }
            });
        }
    }    
   
    const CancelChieuDay = async (e: any) => {
        setOptionChieuDay(prevState => ({
            ...prevState,
            isEditing: false
        }));
        setDataSelectChieuDay({ ...dataSelectChieuDay, model: datamodelthicknessIDInit, thicknessID: '' });
        setmodelthicknessID(datamodelthicknessIDInit);
    }
    const hilightrow = (row:cateThickness) => {
        if (row.thicknessID === modelthicknessID.thicknessID) {
          return { background: "#57b4bd ", color: "#fff" };
        }
        return null;
    };

    return (
        <Fragment>
            <div className="page-pannel">
                <div className="page-pannel-float-left w-40">
                    <div className="pannel-header">
                        DANH MỤC CHIỀU DÀY
                    </div>
                    <div className="pannel-full-body">                        
                            <DataGrid
                                filterable
                                filterRules={[]}
                                data={model.lst}
                                style={{ height: (window.innerHeight - 120) }}
                                selectionMode="single"
                                onSelectionChange={onSelectChieuDay}
                                selection={selectChieuDay}
                                rowCss={hilightrow}
                                >                                
                                <GridColumn field="thicknessID" title="Mã" width="35%" align="center" />
                                <GridColumn field="thicknessName" title="Tên" width="60%" align="center"/>                                                   
                            </DataGrid>                        
                    </div>
                </div>
                <div className="page-pannel-float-left w-60">
                    <div className="pannel-body" style={{ marginBottom: 20 }}>
                        <section className="code-box-meta thicknessIDrkdown">
                            <div className="code-box-title">Thông tin chiều dày</div>
                            <div className="code-box-description">
                                <div className="text-left">
                                    <div className="lable-cotrol inline-bolck mr-right-5 ">
                                        Mã
                                    </div>
                                    <div className="inline-bolck mr-right-5 input-control w-30">
                                        <Input size="small" disabled={!optionChieuDay.isEditing}  maxLength={10} name="thicknessID" value={modelthicknessID.thicknessID} onChange={handleChangeInput} />
                                    </div>     
                                    <div className="lable-cotrol inline-bolck mr-right-5 ">
                                        Tên
                                    </div>
                                    <div className="inline-bolck mr-right-5 input-control w-30">
                                        <Input size="small" disabled={!optionChieuDay.isEditing} name="thicknessName" value={modelthicknessID.thicknessName} onChange={handleChangeInput} />
                                    </div>                                    
                                </div>
                                <div className="clearfix"></div>
                            </div>
                        </section>
                    </div>
                    <div className="pannel-footer">
                        {optionChieuDay.isEditing ?
                            <div>
                                <Button className="button" loading={optionChieuDay.isSubmit} type="primary" icon="save" size="small" onClick={e => SaveChieuDay(e)}>Lưu</Button>
                                <Button className="button" disabled={optionChieuDay.isSubmit} type="dashed" icon="close" size="small" onClick={e => CancelChieuDay(e)}>Hủy</Button>
                            </div>
                            :
                            <div>
                                <Button className="button" type="primary" icon="plus" size="small" onClick={e => AddChieuDay(e)}>Thêm</Button>
                                <Button className="button" type="primary" icon="edit" size="small" onClick={e => EditChieuDay(e)}>Sửa</Button>
                                <Button className="button" type="dashed" icon="close" size="small" onClick={e => DeleteChieuDay(e)}>Xóa</Button>
                            </div>
                        }
                    </div>
                </div>
            </div>
        </Fragment>
    )
}
export default ChieuDay;
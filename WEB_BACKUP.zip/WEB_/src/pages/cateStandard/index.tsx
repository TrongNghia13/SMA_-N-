import React, { Fragment, useState, useEffect } from 'react';
import { GridColumn, DataGrid } from 'rc-easyui';
import { Button, message, Modal, Input } from 'antd';
import TieuChuanNLController from '../../services/cateStandardService';
import DM_TIEUCHUAN from '../../models/cateStandard';
import { APIStatus } from '../../configs/APIConfig';
import {PlusOutlined, EditOutlined, DeleteOutlined, SaveOutlined,CloseOutlined} from '@ant-design/icons';

const tieuChuanController = new TieuChuanNLController();

const { confirm } = Modal;
const CateStandard: React.FC = () => {        
    const [model, setModel] = useState({ lst: Array<DM_TIEUCHUAN>(), loading: true });
    const dataModelManagerInit = {
        standardID: '',        
        standardName: '',
        // managetype: 1
    };
    const [modelManager, setModelManager] = useState((() => {
        let dataInit: DM_TIEUCHUAN = dataModelManagerInit
        return dataInit;
    }));
    const [dataSelectTieuChuan, setDataSelectTieuChuan] = useState((() => {
        let dataInit = { model: dataModelManagerInit, standardID: '' }
        return dataInit;
    }));
    const [optionTieuChuan, setOptionTieuChuan] = useState((() => {
        let dataInit = { standardID: '', isEditing: false, isSubmit: false, isCreate: false };
        return dataInit;
    }));
    const [selectTieuChuan, setSelectTieuChuan] = useState((() => {
        let dataInit: DM_TIEUCHUAN = {} as any;
        return dataInit;
    })); 

    useEffect(() => {
        LoadDMTieuChuan();
    }, []);

    const LoadDMTieuChuan= async (callback?: any) => {
        var dataDMTieuChuan = await tieuChuanController.GetList();
        setModel({
            ...model,
            lst: dataDMTieuChuan.data,
            loading: false
        });
        setTimeout(() => {
            if (callback) callback(dataDMTieuChuan.data);
        }, 300);
    }    
    
    const onSelectTieuChuan = (selection: DM_TIEUCHUAN, dataInit?: Array<DM_TIEUCHUAN>) => {
        if (optionTieuChuan.isEditing && (dataInit == null || dataInit === undefined)) {
            setDataSelectTieuChuan({ ...dataSelectTieuChuan, model: dataModelManagerInit, standardID: '' });            
        }
        else {            
            var tieuchuanItem: DM_TIEUCHUAN = dataModelManagerInit;
            if (dataInit) {
                tieuchuanItem = dataInit.find((element) => {
                    return element.standardID === selection.standardID;
                }) || dataModelManagerInit;
            }
            else {
                tieuchuanItem = model.lst.find((element) => {
                    return element.standardID === selection.standardID;
                }) || dataModelManagerInit;
            }
            // tieuchuanItem.managetype = 2;
            setModelManager(tieuchuanItem);
            setDataSelectTieuChuan({ ...dataSelectTieuChuan, model: tieuchuanItem });

            setOptionTieuChuan(prevState => ({
                ...prevState,
                standardID: tieuchuanItem.standardID,
                standardName: tieuchuanItem.standardName,
                isEditing: false,
                isSubmit: false,
            }));            
        }
    }

    const handleChangeInput = (e: React.FormEvent<HTMLInputElement>) => {
        e.preventDefault();
        let { type, name, value } = e.currentTarget;
        setModelManager({ ...modelManager, [name]: (type === 'number' ? parseFloat(value) : value) });
    }

    const AddTieuChuan = (e: any) => {
        setOptionTieuChuan(prevState => ({
            ...prevState,
            standardID:"",
            isEditing: true,
            isCreate : true
        }));
        setDataSelectTieuChuan({ ...dataSelectTieuChuan, model: dataModelManagerInit, standardID: '' });
        setModelManager(dataModelManagerInit);
    }

    const EditTieuChuan = (e: any) => {
        if (optionTieuChuan.standardID.length <= 0) {
            message.error('Vui lòng chọn thông tin để sửa');
            return false;
        }
        setOptionTieuChuan(prevState => ({ ...prevState, isEditing: true, isCreate : false  }));
    }

    const DeleteTieuChuan = (e: any) => {       
        if (optionTieuChuan.standardID.length <= 0) {            
            message.error('Vui lòng chọn thông tin để xóa');
            return false;
        }
        confirm({            
            title: 'Xác nhận',
            content: 'Bạn có chắc muốn xóa danh mục: ' + optionTieuChuan.standardID + '?',
            onOk() {
                OnDeletedTieuChuan(e);
            },
            onCancel() { },
        });
    }

    const OnDeletedTieuChuan = async (e: any) => {
        var reDelete = await tieuChuanController.Delete(optionTieuChuan.standardID);;
        if (reDelete.status === APIStatus.ERROR) {
            message.error(reDelete.message);
        }
        else {                        
            await LoadDMTieuChuan();
            await CancelTieuChuan(e);
        }
    }

    const SaveTieuChuan = async (e: any) => {
        console.log(optionTieuChuan.isCreate);
        var data : any ;
        setOptionTieuChuan({ ...optionTieuChuan, isSubmit: true });
        if(optionTieuChuan.isCreate){
            data = await tieuChuanController.Create(modelManager);
        } else {
            data = await tieuChuanController.Update(modelManager);
        }
        if (data.status === APIStatus.ERROR) {
            message.error(data.message);
            setOptionTieuChuan({ ...optionTieuChuan, isSubmit: false });
        }
        else {
            message.success('Cập nhật thành công');
            CancelTieuChuan(e);
            await LoadDMTieuChuan(function (datas: Array<DM_TIEUCHUAN>) {
                var tieuchuanItem = datas.find((element) => {
                    return element.standardID === data.data;
                });
                if (tieuchuanItem) {
                    onSelectTieuChuan(tieuchuanItem, datas);
                }
            });
        }
    }

    const CancelTieuChuan = async (e: any) => {
        setOptionTieuChuan(prevState => ({
            ...prevState,
            isEditing: false
        }));
        setDataSelectTieuChuan({ ...dataSelectTieuChuan, model: dataModelManagerInit, standardID:"" });
        setModelManager(dataModelManagerInit);
    }
    const hilightrow = (row: DM_TIEUCHUAN) => {
        if (row.standardID === modelManager.standardID) {
          return { background: "#57b4bd ", color: "#fff" };
        }
        return null;
    };

    return (
        <Fragment>
            <div className="page-pannel">
                <div className="page-pannel-float-left w-40">
                    <div className="pannel-header">
                        DANH MỤC TIÊU CHUẨN
                    </div>
                    <div className="pannel-full-body">                        
                            <DataGrid
                                filterable
                                filterRules={[]}
                                data={model.lst}
                                style={{ height: (window.innerHeight - 120) }}
                                selectionMode="single"
                                onSelectionChange={onSelectTieuChuan}
                                selection={selectTieuChuan}
                                rowCss={hilightrow}
                                >                                
                                <GridColumn field="standardID" title="Mã" width="35%" align="center" />
                                <GridColumn field="standardName" title="Tên" width="60%" align="center"/>                                                   
                            </DataGrid>                        
                    </div>
                </div>
                <div className="page-pannel-float-left w-60">
                    <div className="pannel-body" style={{ marginBottom: 20 }}>
                        <section className="code-box-meta markdown">
                            <div className="code-box-title">Thông tin tiêu chuẩn</div>
                            <div className="code-box-description">
                                <div className="text-left">
                                    <div className="lable-cotrol inline-bolck mr-right-5 ">
                                        Mã
                                    </div>
                                    <div className="inline-bolck mr-right-5 input-control w-30">
                                        <Input size="small" maxLength={10} name="standardID" value={modelManager.standardID} onChange={handleChangeInput} />
                                    </div>     
                                    <div className="lable-cotrol inline-bolck mr-right-5 ">
                                        Tên
                                    </div>
                                    <div className="inline-bolck mr-right-5 input-control w-30">
                                        <Input size="small" disabled={!optionTieuChuan.isEditing} name="standardName" value={modelManager.standardName} onChange={handleChangeInput} />
                                    </div>                                    
                                </div>
                                <div className="clearfix"></div>
                            </div>
                        </section>
                    </div>
                    <div className="pannel-footer">
                        {optionTieuChuan.isEditing ?
                        <div>
                        <Button className="button" shape="default" loading={optionTieuChuan.isSubmit} type="primary" icon={<SaveOutlined/>} onClick={e => AddTieuChuan(e)}>Lưu</Button>
                        <Button className="button" shape="default" disabled={optionTieuChuan.isSubmit} type="dashed" icon={<CloseOutlined/>} onClick={e => CancelTieuChuan(e)} danger>Hủy</Button>
                    </div>
                    :
                    <div>
                        <Button className="button" type="primary"  icon={<PlusOutlined />}  onClick={e => AddTieuChuan(e)}>Thêm</Button>
                        <Button className="button" type="primary"  icon={<EditOutlined />} onClick={e => EditTieuChuan(e)} >Sửa</Button>
                        <Button className="button" type="primary"  icon={<DeleteOutlined />} onClick={e => DeleteTieuChuan(e)} danger>Xóa</Button>
                    </div>
                        }
                    </div>
                </div>
            </div>
        </Fragment>
    )
}
export default CateStandard;
import React from 'react';
import { Route, Navigate, RouteProps ,Routes,useNavigate} from 'react-router-dom';
import LoginUtils from '../utils/loginUtils';

// type PrivateRouteProps = RouteProps & {
//     component: any;
//   };

// const PrivateRoute = (props: PrivateRouteProps) => {
//     let navigate = useNavigate();
//   const { component: Componet, ...rest } = props;
//   const IsLogin = LoginUtils.IsLogin();
//   console.log(IsLogin);
//   return (
//     <Routes>
//     <Route
//       {...rest}
//       element={
//         IsLogin ? (
//         //   <Component />;
//           <Route path="/homepage" element={props.component} />

//         ) : (
//          <Route path="/Login" element={props.component} />
//         //   <Navigate to="/Login"/>
//         )
//       }
//     />
//     </Routes>
//   );
// };
// Sửa lại thành phần PrivateRoute
const PrivateRoute = (props:any) => {
    const IsLogin = LoginUtils.IsLogin();
    return IsLogin ? props.children : <Navigate to="/login" />; // Trả về các thành phần con hoặc một Navigate
  };
export default PrivateRoute;
